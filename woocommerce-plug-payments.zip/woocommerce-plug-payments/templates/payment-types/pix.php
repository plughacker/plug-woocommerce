<div id="plugpayments-pix-form" class="plugpayments-method-form">
    O QR Code do PIX será exibido <strong>após a confirmação de compra.</strong>
</div>