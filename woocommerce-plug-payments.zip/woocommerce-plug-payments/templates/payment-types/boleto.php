<div id="plugpayments-boleto-form" class="plugpayments-method-form">
    O Boleto com o código de barras será exibido <strong>após a confirmação de compra.</strong>
</div>