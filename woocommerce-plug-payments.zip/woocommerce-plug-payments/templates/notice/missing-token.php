<div class="error inline">
	<p><strong><?php _e( 'Plug Disabled', 'woocommerce-plugpayments' ); ?></strong>: <?php _e( 'You should inform your tokenId.', 'woocommerce-plugpayments' ); ?>
	</p>
</div>
