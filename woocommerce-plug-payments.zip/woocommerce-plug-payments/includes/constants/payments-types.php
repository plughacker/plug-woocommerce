<?php
define( 'WC_PLUGPAYMENTS_PAYMENTS_TYPES', array(
    'credit' => 'Credit',
    'pix' => 'Pix',
    'boleto' => 'Boleto'
) );

define( 'WC_PLUGPAYMENTS_BR_TYPES', array(
    'pix' => 'Pix',
    'boleto' => 'Boleto'
) );